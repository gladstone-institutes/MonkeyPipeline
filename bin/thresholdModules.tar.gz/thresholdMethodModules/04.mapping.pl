#!/usr/bin/perl
#PBS -l nodes=1:ppn=1
#PBS -l walltime=160:00:00
#PBS -o X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.out
#PBS -e X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.err

# Warning: if you have a single quote on a PBS comment line above, it will trigger a "qsub: unmatched" error and exit code 1.
my $syslog = "X.04.mapping.syslog.txt";

use strict; use warnings; use Carp; # Carp = "confess" function
use File::Spec::Functions qw(catfile);
use File::Basename; # for dirname and basename
use Data::Dumper;
use lib "/data/work/Common/Code/alexgw/monkey_agw"; # To make sure we find bananas_agw
use bananas_agw;

sub getSampleFileName($$) { my ($rDir, $file) = @_; return catfile($rDir,(bananas_agw::noExtensions($file) . ".gz")); }

bananas_agw::requireEnvOrDie('aligner','samtools','minMapQ','filterDir','mappingDir','sampleName','inputFile1','bowtie2Index','finalBam','sortMethod'); # <-- these vars MUST be defined in the %ENV hash

my $force       = bananas_agw::envLooksTrue("force");
my $verbose     = bananas_agw::envLooksTrue("verbose");
my $finalBam    = $ENV{'finalBam'}; #catfile($ENV{'mappingDir'},"$sampleName_${genome}_q${mapq}.bam"); # example of what this looks like: mysample_mm9_q30.bam
my $isPaired    = (defined($ENV{'inputFile2'}) && (length($ENV{'inputFile2'}) > 0) && (uc($ENV{'inputFile2'}) ne "NA")); # if inputFile2 is defined, then we assume we DO have a paired sample!
my $fqFile1     =               getSampleFileName($ENV{'filterDir'},$ENV{'inputFile1'});
my $fqFile2     = ($isPaired) ? getSampleFileName($ENV{'filterDir'},$ENV{'inputFile2'})  :  ""; # make sure it is EMPTY if the file is not paired!
my $mapq        = $ENV{'minMapQ'}; # should be a number from 0 to ... maybe 50 at most normally
my $sortMethod  = $ENV{'sortMethod'};
my $sampleName  = $ENV{'sampleName'};
my $alignerLog  = "${finalBam}.log";
my $gtf         = exists($ENV{'gtfFile'}) ? $ENV{'gtfFile'} : undef; # <-- A GTF annotation file is used by Tophat, but not by Bowtie!

my $numThreads  = exists($ENV{'ncpu'}) ? $ENV{'ncpu'} : 4; # Default number of threads is 4 if the 'ncpu' parameter wasn't explicitly specified
$numThreads =~ m/^(\d)+$/ or confess "[ERROR] 04.mapping.pl. numThreads (ncpu) must be an integer, whereas you passed in this value: $ENV{'ncpu'} <-- non-integer value";

# ========== Check prior completion and exit if the files exist ========
if (-e $finalBam and !$force) { # Does the file ALREADY exist AND we aren't forcing a re-run? Then skip it.
    ($verbose) && print STDOUT "[OK] [SKIPPING RE-RUN]: the already-aligned file '$finalBam' (for sample '$sampleName') already exists, so we will not re-align it.\n";
    exit(0); # This is OK, exit without an error!
}

my $BYCOORD = "BY_COORD";
my $BYNAME  = "BY_NAME";

# =========== Check a bunch of error conditions ===========
(uc($sortMethod) eq $BYNAME or uc($sortMethod) eq $BYCOORD) or confess "[ERROR] 04.mapping.pl: The 'sortMethod' parameter must be either the literal text '$BYNAME' or '$BYCOORD'. It cannot be ANYTHING else. You specified '$sortMethod', however. Fix this!";
(-e $fqFile1)                                               or confess "[ERROR] 04.mapping.pl: Cannot find the input fastq file 1 ('fqFile1') named '$fqFile1'! Check to make sure this file really exists on the filesystem. Also make sure it is a FULL path, not a relative path.";
($mapq >= 0 and $mapq <= 999 and ($mapq == int($mapq)))     or confess "[ERROR] 04.mapping.pl: mapq was set to the weird value of '$mapq'--but it should really be an INTEGER in the range from 0 and ... maybe 50 at most? (Probably lower, like 30).";
bananas_agw::mkdirOrDie($ENV{'mappingDir'});

if ($ENV{'aligner'} =~ /tophat/i) { # ~~~~~~~~ TOPHAT (actually Tophat2) ~~~~~~~~
    ($sortMethod eq $BYCOORD) or confess "With tophat, we actually only support '$BYCOORD', not '$BYNAME' sorting.";
    (defined($gtf)) or confess "FATAL ERROR in 4.mapping.pl: Tophat needs a GTF annotation file. However, the 'gtfFile' line in your monkey config file did NOT specify one! If you do not have such a file, set it to 'gtfFile = NA' to not use a GTF file at all.";
    ((uc($gtf) eq "NONE") or (uc($gtf) eq "NA") or (-e $gtf)) or confess "[FATAL ERROR] 04.mapping.pl: The following GTF annotation file, which was specified in the config file, and is MANDATORY for Tophat, doesn't exist: \"$gtf\"";
    my $dirThatContainsBowtie = dirname($ENV{'aligner'}); # the "dirname" function is located in File::Basename. This is IMPORTANT to include on the tophat command, otherwise Tophat will not locate Bowtie properly if it isn't in the default path (which it might not be!).
    my $subdirName            = "${sampleName}.tophat.dir"; # NOT the path
    my $topOutDir             = catfile($ENV{'mappingDir'}, "${subdirName}");
    my $tophat_GTF_string     = ((uc($gtf) eq "NONE") or (uc($gtf) eq "NA")) ? " " : " --GTF=$gtf ";
    my $pairedMateDist        = 50; # <-- this is MANUALLY specified here for now... turns out basically not to matter
    my $tophatArgs            = " ${tophat_GTF_string} --min-anchor=5 --segment-length=25 --no-coverage-search --segment-mismatches=2 --splice-mismatches=2 --num-threads=$numThreads " . (($isPaired) ? " --mate-inner-dist=$pairedMateDist " : " ");
    my $topOutBamInSubdir     = catfile($topOutDir, "accepted_hits.bam");

    my $filteredBamNameOnly   = "accepted_filtered_q${mapq}.bam";
    my $filteredBam           = catfile($topOutDir, $filteredBamNameOnly); # <-- this is the final output file of interest with only the reads that met the 'mapq' threshold
    my $mapqLog               = catfile($topOutDir, "mapq.samtools.filtering.txt.log");
    bananas_agw::systemAndLog("PATH=\$PATH:${dirThatContainsBowtie} &&  $ENV{'aligner'} -o $topOutDir $tophatArgs $ENV{'bowtie2Index'} $fqFile1 $fqFile2 2> $alignerLog", $verbose, $syslog); # <-- Note that the PATH is manually specified in order to add the directory with Bowtie in it, to prevent Tophat from failing to find Bowtie under certain circumstances.
    bananas_agw::systemAndLog("$ENV{'samtools'} view -q $mapq -h -b $topOutBamInSubdir > $filteredBam 2> $mapqLog", $verbose, $syslog); # filter for the minMapQ

    my $filteredBamLocalPath = catfile($subdirName, $filteredBamNameOnly); # NOT an absolute path!!
    bananas_agw::systemAndLog("ln -f -s $filteredBamLocalPath $finalBam", $verbose, $syslog); # <-- note: in the tophat case, the 'finalBam' is a symlink (this is OK). The 'real' non-symlink file is $filteredBam.

} elsif ($ENV{'aligner'} =~ /bowtie/i) { # ~~~~~~~~ BOWTIE (actually Bowtie2) ~~~~~~~~
    my $outSam               = catfile($ENV{'mappingDir'}, "${sampleName}.sam"); # example of what this looks like: mysample.sam. 
    my $bamConversionLog     = "${finalBam}.conversion_log.txt"; # bowtie only
    my $FILE_PAIR_INPUT_TEXT = ($isPaired) ? " -1 $fqFile1 -2 $fqFile2 " : " -U $fqFile1 ";
    my $uncompressedBamTmp   = "${finalBam}_SORT_TEMP_DELETE_ME_SOON_tmp.bam";
    my $samTmp = "${outSam}.temp_mapping_in_progress.sam";
    my $outCode = bananas_agw::systemAndLog("$ENV{'aligner'} --threads=$numThreads -x $ENV{'bowtie2Index'} $FILE_PAIR_INPUT_TEXT -S $samTmp   2>  $alignerLog", $verbose, $syslog);
    (0 == $outCode) or confess "[ERROR] 04.mapping.pl:  Bowtie returned a non-zero exit code ($outCode). Something went wrong. Fix the mapping script!";
    bananas_agw::systemAndLog("/bin/mv -f $samTmp $outSam", $verbose, $syslog); # Mvoe the temp file to the final destination now that we know it is theoretically correct. This avoids having a good-looking sam file that is actually broken.
    (-e $outSam) or confess "[ERROR] 04.mapping.pl:  Bowtie / samtools somehow FAILED to generate the file '$outSam'. Something went wrong. Fix the mapping script!";
    if (uc($sortMethod) eq uc($BYCOORD)) { bananas_agw::systemAndLog("$ENV{'samtools'} view -q ${mapq} -S -h -u -b ${outSam} > $uncompressedBamTmp 2> ${bamConversionLog};    $ENV{'samtools'} sort ${uncompressedBamTmp} -o ${finalBam}  2>>  ${bamConversionLog}", $verbose, $syslog); } # <-- POSITIONALLY SORTED (COORDINATE SORTED output bam)
    if (uc($sortMethod) eq uc($BYNAME) ) { bananas_agw::systemAndLog("$ENV{'samtools'} view -q ${mapq} -S -h    -b ${outSam} > ${finalBam}         2> ${bamConversionLog}", $verbose, $syslog); print STDERR "WARNING: lexographic sorting is usually a bad idea and will probably break things downstream! It will for sure break RSeQC, and most likely other tools!\n"; } # <-- LEXOGRAPHICALLY SORTED output bam
    if (not -e $finalBam) {
	    bananas_agw::systemAndLog("touch ${finalBam}_FAILED_FOR_SOME_REASON_CHECK_LOGS", $verbose, $syslog);
	    confess "[ERROR] 04.mapping.pl: Failed to create a SORTED file ('$finalBam') from input file '$outSam'--something went wrong in 'samtools' sorting.";
    }
    unlink($outSam); ($verbose) && print STDERR "[OK] 04.mapping.pl: Removed the no-longer-needed SAM file <$outSam>.\n"; # <-- delete the output sam file after it gets converted to a bam file!
    if (-e $uncompressedBamTmp) { unlink($uncompressedBamTmp); ($verbose) && print STDERR "[OK] 04.mapping.pl: Removed the temporary (used for sorting) uncompressed BAM file <${uncompressedBamTmp}>.\n"; }
} else {
    confess "[ERROR] 04.mapping.pl: Error in MAPPING: The following aligner was not supported (the only ones supported are 'tophat' and 'bowtie'): <$ENV{'aligner'}>. Check to make sure that is IN FACT exactly what you want it to be! Watch out for misspellings!";
}

(-e "${finalBam}") or confess "[ERROR] 04.mapping.pl: in mapping: Somehow we failed to generate the final sorted-and-filtered bam file '$finalBam'. This probably will cause serious problems downstream..";

bananas_agw::systemAndLog("samtools index $finalBam", $verbose, $syslog); # <-- Generate an index (bam.bai) file, which is OCCASIONALLY needed (for example, for RSEQC and for IGV)
(-e "${finalBam}.bai") or confess "[ERROR] 04.mapping.pl: in samtools indexing: failed to created the expected '.bai' index file named <${finalBam}.bai .";
