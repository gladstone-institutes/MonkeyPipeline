#!/usr/bin/perl
#PBS -l nodes=1:ppn=1
#PBS -l walltime=500:00:00
#PBS -o X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.out
#PBS -e X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.err
# Warning: if you have a single quote on a PBS comment line above, it will trigger a "qsub: unmatched" error and exit code 1.

use strict; use warnings; use Carp; # Carp = "confess" function
use File::Spec::Functions qw(catfile);
use Data::Dumper;
use lib "/data/work/Common/Code/alexgw/monkey_agw"; use bananas_agw; # To make sure we find bananas_agw

my $force                = bananas_agw::envLooksTrue("force");
my $verbose              = bananas_agw::envLooksTrue("verbose");
my $debug                = bananas_agw::envLooksTrue("debug"); # extra-verbose
my $shouldFilterAdapters = bananas_agw::envLooksTrue("shouldFilterAdapters"); # If this is TRUE, then we filter. If it is FALSE, then we don't actually do any filtering (we just symlink input -> output VERBATIM, directly)

bananas_agw::requireEnvOrDie('fastqDir','filterDir','inputFile1', 'shouldFilterAdapters'); # We always need these variables, even if we *aren't* filtering.
if ($shouldFilterAdapters) { 
	bananas_agw::requireEnvOrDie('fastqMcf', 'adapterFile'); # We ALSO need these variables if we are filtering
	(-e $ENV{'fastqMcf'})    or confess "[ERROR] fastq-mcf executable location did not appear to actually exist (check that this is valid: $ENV{'fastqMcf'} ) ...";
	(-e $ENV{'adapterFile'}) or confess "[ERROR] Adapter file <$ENV{'adapterFile'}> appears not to be a valid file! ...";
}
(-d $ENV{'fastqDir'})    or confess "[ERROR] Error in filtering (02.filter.pl) -- the FASTQ input file directory <$ENV{'fastqDir'}> appears not to exist! ";

# check if reads are paired end
my $isPaired = ((not bananas_agw::isNA($ENV{'inputFile2'})) and ($ENV{'inputFile2'} ne "")) ? 1 : 0;
my $fq1      =               catfile($ENV{'fastqDir'}, $ENV{'inputFile1'});
my $fq2      = ($isPaired) ? catfile($ENV{'fastqDir'}, $ENV{'inputFile2'}) : "";
(-e $fq1)                 or confess "[ERROR] Failed to find the specified first-pair input file named <$fq1>. Check to make sure this file exists AND there is a full path to this file AND that the file does not have any special characters or spaces in the name.";
(!$isPaired || (-e $fq2)) or confess "[ERROR] Failed to find the specified second-pair input file named <$fq2>. Check to make sure this file exists AND there is a full path to this file AND that the file does not have any special characters or spaces in the name.";

my ($of1, $of2);
my ($tof1, $tof2); # Temporary files where filtering is written to BEFORE it is totally finished. Only FINISHED and properly-run jobs will get 'promoted' from $tof1 -> $of1 and $tof2 -> $of2
if ($shouldFilterAdapters) {
	# When we perform the filtering, we ALWAYS gzip the output!
	$of1 =               catfile($ENV{'filterDir'}, bananas_agw::noExtensions($ENV{'inputFile1'}).".gz");
	$of2 = ($isPaired) ? catfile($ENV{'filterDir'}, bananas_agw::noExtensions($ENV{'inputFile2'}).".gz") : "";

	$tof1 =               catfile($ENV{'filterDir'}, "temp_".bananas_agw::noExtensions($ENV{'inputFile1'}).".gz");
	$tof2 = ($isPaired) ? catfile($ENV{'filterDir'}, "temp_".bananas_agw::noExtensions($ENV{'inputFile2'}).".gz") : "";	
	
} else {
	# If we aren't actually performing filtering, then we just symlink the original input, which MAY possibly not be gzipped.
	# In that unlikely case, we will just symlink the original filename without the gz suffix.
	# Whatever the case may be, ".gzip" is always changed to ".gz".
	my $is_fq1_gzipped = ($fq1 =~ m/[.](gz|gzip)$/i);
	my $is_fq2_gzipped = ($fq2 =~ m/[.](gz|gzip)$/i);
	my $fq1_compression_suffix = ($is_fq1_gzipped) ? ".gz" : "";
	my $fq2_compression_suffix = ($is_fq2_gzipped) ? ".gz" : "";
	$of1 =               catfile($ENV{'filterDir'}, bananas_agw::noExtensions($ENV{'inputFile1'}.$fq1_compression_suffix));
	$of2 = ($isPaired) ? catfile($ENV{'filterDir'}, bananas_agw::noExtensions($ENV{'inputFile2'}.$fq2_compression_suffix)) : "";
	
	$tof1 =               catfile($ENV{'filterDir'}, "temp_".bananas_agw::noExtensions($ENV{'inputFile1'}.$fq1_compression_suffix));
	$tof2 = ($isPaired) ? catfile($ENV{'filterDir'}, "temp_".bananas_agw::noExtensions($ENV{'inputFile2'}.$fq2_compression_suffix)) : "";
}

my $resultFilesExistAlready = (-e "${of1}") and (!$isPaired or -e "${of2}");
if (not $force and $resultFilesExistAlready) { # Do the file(s) ALREADY exist AND we aren't forcing a re-run? Then skip it/them.
	($isPaired) && $verbose && print STDOUT    "[OK] SKIPPING re-filtering of single-end input file <$fq1>, because the output file <$of1> already exists.\n";
	($isPaired) && $verbose && print STDOUT (qq{[OK] SKIPPING re-filtering of paired-end input files <$fq1> (left half)...\n} .
						 qq{                                              ...and <$fq2> (right half), because both output files (<$of1> and <$of2>) already exist.\n});
	exit(0);
}

# Check for bzipped files and warn the user if they are seen! fastq-mcf can only handle .gz and uncompressed files.
($fq1 !~ m/[.](bz2|bzip2)$/i and $fq2 !~ m/[.](bz2|bzip2)$/i) or confess "[ERROR]: Sorry, although fastq-mcf CAN handle gzipped (.gz) and uncompressed fasta files, but it CANNOT handle .bz2 files. Check <$fq1> and <$fq2> to make sure they are gzipped and not .bz2.";

bananas_agw::dieIfFileAccessFails($fq1);
if ($isPaired) { bananas_agw::dieIfFileAccessFails($fq2); }

bananas_agw::mkdirOrDie($ENV{'filterDir'});

if ($shouldFilterAdapters) {
	# Note: fastq-mcf uses the DEFAULT quality filtering threshold if you don't give it one.
	#      *  For example, "-q 10" is the default if not overridden.
	# We have, as you can see here, overridden it with the "$phredQualThresh" variable to allow us to change this in the future.
        my $phredQualThresh = 10;

	my $logName = ($isPaired) ? "${of1}.paired.fastqmcf_log.txt" : "${of1}.fastqmcf_log.txt"; # Always the first file, even when paired-end
	my $cmd = "need to set this";
	if ($isPaired) { $cmd = qq{$ENV{'fastqMcf'} -q $phredQualThresh -o $tof1 -o $tof2 $ENV{'adapterFile'} $fq1 $fq2 > $logName}; }
	else {           $cmd = qq{$ENV{'fastqMcf'} -q $phredQualThresh -o $tof1          $ENV{'adapterFile'} $fq1      > $logName}; }

	my $exitCode = bananas_agw::systemAndLog($cmd, $verbose);
	($exitCode == 0) or confess("02.filter.pl: Filtering step failure -- exit code of fastq-mcf command must be zero! The command exited with code $exitCode, and the full command was: $cmd ");

	# Ok, since the files were apparently generated correctly above, NOW we can move them from "$tof" (temp out file) to "$of" (out file)
	bananas_agw::systemAndLog(                "/bin/mv -f $tof1 $of1", $verbose);
	($isPaired) and bananas_agw::systemAndLog("/bin/mv -f $tof2 $of2", $verbose);
	
} else {
	# If we skip the filtering step, we just make SYMLINKS to the original input fastq files.
	# This way, downstream analysis will still find the ""filtered"" (but not really) samples where it expects them to be.
	bananas_agw::systemAndLog(                "/bin/ln -s $fq1 $of1", $verbose); # Don't really filter, just symlink!
	($isPaired) and bananas_agw::systemAndLog("/bin/ln -s $fq2 $of2", $verbose); # Don't really filter, just symlink!
}

bananas_agw::dieIfFileAccessFails(                $of1, "[ERROR]: Failed to generate filtered 1st-end-of-the-pair output file <${of1}>");
(!$isPaired) or bananas_agw::dieIfFileAccessFails($of2, "[ERROR]: Failed to generate filtered 2nd-end-of-the-pair output file <${of2}>");

