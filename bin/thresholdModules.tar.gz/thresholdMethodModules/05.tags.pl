#!/usr/bin/perl
#PBS -l nodes=1:ppn=1
#PBS -l walltime=4:00:00
#PBS -o X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.out
#PBS -e X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.err

use strict;
use warnings;
use File::Spec::Functions qw(catfile);
use Data::Dumper;

# check for correct qsub variables needed to perform mapping
if (!defined(%ENV)) { die "ENV variable not defined in tags script submission\n" }
elsif (!defined($ENV{'force'})) { die "force rerun variable not specified by script\n"}
elsif (!defined($ENV{'genome'})) { die "genome not specific by tags script script\n"}
elsif (!defined($ENV{'seqType'})) { die "sequence type not specific by tags script script\n"}
elsif (!defined($ENV{'samtools'})) { die "samtools file not specified by tags script\n"}
elsif (!defined($ENV{'bam2bed'})) { die "bam2bed file not specified by tags script\n"}
elsif (!defined($ENV{'sortBed'})) { die "sort-bed not specified by tags script\n"}
elsif (!defined($ENV{'tagsDir'})) { die "tags directory not defined in tags script\n"}
elsif (!defined($ENV{'inputFile'})) { die "input file not specified in tags script submission\n"}
elsif (!defined($ENV{'sampleName'})) {die "sample name not defined in tags script\n"}
elsif (!defined($ENV{'isPaired'})) {die "no boolean value indicating paired end status (or not)\n"}

# make sure write directory exists or make it
((-d $ENV{'tagsDir'}) or mkdir($ENV{'tagsDir'})) or die "unable to find or create results directory: $ENV{'tagsDir'}!";

# generate initial bed file
my $oft = catfile($ENV{'tagsDir'},"$ENV{'sampleName'}") . "_" . $ENV{'genome'} . "_tags.bed.tmp";
my $ofSorted = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tags.bed";

# if ($ENV{'force'} || ! -e $ofSorted) { system("$ENV{'bam2bed'} --do-not-sort < $ENV{'inputFile'} | cut -f 1-3,4,6,8 > $oft"); }

# sequence-type-specific processing of tags
if ($ENV{'seqType'} eq "exo") {
    my $pstf = catfile($ENV{'tagsDir'},"$ENV{'sampleName'}") . "_" . $ENV{'genome'} . "_tags.pos.bed";
    my $nstf = catfile($ENV{'tagsDir'},"$ENV{'sampleName'}") . "_" . $ENV{'genome'} . "_tags.neg.bed";

    if ($ENV{'force'} || ! -e $ofSorted) { system("$ENV{'bam2bed'} --do-not-sort < $ENV{'inputFile'} | cut -f 1-3,4,6,8 > $oft"); }
    
    # check prior completion
    unless ($ENV{'force'}) {
	if (-e $ofSorted && -e $pstf && -e $nstf) { exit }
    }

    # process exo tags
    system("$ENV{'sortBed'} $oft | awk '{x=\$2;xu=\$2+1; if (\$5==\"-\") {x=\$3-1;xu=\$3}; print \$1\"\t\"x\"\t\"xu\"\t\"\$4\"\t\"\$5}' > $ofSorted");
    system("awk '{if (\$5==\"+\") {print \$0}}' $ofSorted > $pstf");
    system("awk '{if (\$5==\"-\") {print \$0}}' $ofSorted > $nstf");
}
elsif ($ENV{'seqType'} eq "rna") {
    # check prior completion
    unless ($ENV{'force'}) {
        if (-e $ofSorted) { exit }
    }

    if ($ENV{'force'} || ! -e $ofSorted) { system("$ENV{'bam2bed'} --do-not-sort < $ENV{'inputFile'} | cut -f 1-3,4,6,8 > $oft"); }
    
    # process rna tags
    my $rnaTmp = $oft . "rnaTmp";
    open(F0,$oft) or die "cannot open $oft for filtering spliced reads";
    open(OF,">$rnaTmp");
    while(<F0>) {
	chomp;
	my @t = split(/\t/,$_);
	my $isGapped = 0;
	while ($t[5] =~ /(\d{1,})N/g) {
	    if ($1 >= 10) {$isGapped = 1}
	}
	unless ($isGapped) {printf OF "$_\n"}
    }
    close(F0);
    close(OF);
    system("$ENV{'sortBed'} $rnaTmp | awk '{x=\$2;xu=\$3; print \$1\"\t\"x\"\t\"xu\"\t\"\$4\"\t\"\$5}' > $ofSorted");
    unlink($rnaTmp)
}
elsif ($ENV{'seqType'} eq "atac") {
    # HISEQ:400:H5LT5BCXX:2:1102:17042:35477  163     chr1    10104   30      26M     =       10241   163     AACCCAACCCTAACCCTAACCCTAAC
 
    my $ofLongTmp = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_longFrags.bed.tmp";
    my $ofLongTmp2 = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_longFrags.bed.tmp2";
    my $ofLongTmp3 = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_longFrags.bed.tmp3";
    my $ofLong = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_longFrags.bed";   

    # check prior completion
    unless ($ENV{'force'}) {
	if (-e $ofSorted) { exit }
    }
    
    # collapse paired reads into fragments
    if ($ENV{'isPaired'}) {
	system("$ENV{'samtools'} view $ENV{'inputFile'} | awk '{x = \$4-1; y = x + \$9; x=x+4; y=y-5; print \$3\"\t\"x\"\t\"y }' > $ofLongTmp ");
	system("cat $ofLongTmp | awk '{if (\$3 > \$2 && \$2 > 0) { print \$0 }}' > $ofLongTmp2");
	system("$ENV{'sortBed'} $ofLongTmp2 | uniq > $ofLongTmp3");
	system("cat $ofLongTmp3 | awk '{x=\$2; xd=\$2+1; y=\$3-1; yd=\$3; print \$1\"\t\"x\"\t\"xd; print\$1\"\t\"y\"\t\"yd }' > $oft");
	system("$ENV{'sortBed'} $oft > $ofSorted");
	system("cat $ofLongTmp3 | awk '{if (\$3-\$2 >=150) {print \$0}}' > $ofLong ");
	unlink($ofLongTmp,$ofLongTmp2,$ofLongTmp3);
    }
    else {
	printf STDERR "WARNING: ATAC-seq reads should be paired end otherwise we cannot extract nucleosome positioning information\n";
    }    
}
elsif ($ENV{'seqType'} eq "chip") {
    # check prior completion
    unless ($ENV{'force'}) {
        if (-e $ofSorted) { printf "job previous completed...($ofSorted)\n"; exit }
    }

    if ($ENV{'force'} || ! -e $ofSorted) { system("$ENV{'bam2bed'} --do-not-sort < $ENV{'inputFile'} | cut -f 1-3,4,6,8 > $oft"); }

    # process tags
    my $shiftDistance = 100; 
    system("$ENV{'sortBed'} $oft | awk '{x=\$2 + $shiftDistance; xu=x+1; if (\$5==\"-\") {x=\$3-$shiftDistance-1;xu=\$3-$shiftDistance}; print \$1\"\t\"x\"\t\"xu\"\t\"\$4\"\t\"\$5}' | uniq > $ofSorted");
}
elsif ($ENV{'seqType'} eq "other") {
    # check prior completion
    unless ($ENV{'force'}) {
	if (-e $ofSorted) { printf "job previous completed...($ofSorted)\n"; exit }
    }

    if ($ENV{'force'} || ! -e $ofSorted) { system("$ENV{'bam2bed'} --do-not-sort < $ENV{'inputFile'} | cut -f 1-3,4,6,8 > $oft"); }
    
    # process tags
    system("$ENV{'sortBed'} $oft | awk '{x=\$2;xu=\$2+1; if (\$5==\"-\") {x=\$3-1;xu=\$3}; print \$1\"\t\"x\"\t\"xu\"\t\"\$4\"\t\"\$5}' > $ofSorted");
}
else { die "$ENV{'seqType'} sequence type is not currently supported"}

unlink($oft);
