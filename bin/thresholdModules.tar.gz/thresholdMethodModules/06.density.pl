#!/usr/bin/perl
#PBS -l nodes=1:ppn=1
#PBS -l walltime=128:00:00
#PBS -o X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.out
#PBS -e X.logs/X.${PBS_JOBNAME}.${PBS_JOBID}.err

use strict;
use warnings;
use File::Spec::Functions qw(catfile);
use Data::Dumper;
use lib "/data/work/Common/Code/alexgw/monkey_agw"; # To make sure we find bananas_agw
use bananas_agw;

sub normalizeCounts {
    my ($itags,$iCounts,$tags,$counts) = @_;

    my $c = 0;
    open(TF,$tags) or die "Cannot open tag file for counting lines: $tags\n";
    while(<TF>) {
	$c++;
    }
    close(TF);

    my $tfile = $counts . ".normTmp";

    if ($itags ne "NA" && $iCounts ne "NA") {
	# matched input
	my $ic = 0;
	open(TF,$itags) or die "Cannot open input tag file for counting lines: $itags\n";
	while(<TF>) {
	    $ic++;
	}
	close(TF);

	my $ib=0;
	my $itc;
        open(TF,$iCounts) or die "Cannot open counts file: $counts\n";
        while(<TF>) {
	    $itc->[$ib] = $_;
            $ib++;
        }
        close(TF);

	my $i=0;
	open(OF,">$tfile") or die "Cannot open temporary file for normalization: $tfile\n";
        open(TF,$counts) or die "Cannot open count file for tag density normalization: $counts\n";
	while(<TF>) {
	    my $x = ($_/$c) - ($itc->[$i]/$ic);
            my $v = int($x*$ib*10+0.49999)/10; # <-- 
	    if ($v<0) {$v=0;}
            printf OF "$v\n";
	    $i++;
        }
        close(TF);
        close(OF);
        system("mv -f $tfile $counts");
    }
    else {
	# no matched input
	my $b=0;
	open(TF,$counts) or die "Cannot open counts file: $counts\n";
	while(<TF>) {
	    $b++;
	}
	close(TF);

	open(OF,">$tfile") or die "Cannot open temporary file for normalization: $tfile\n";
	open(TF,$counts) or die "Cannot open count file for tag density normalization: $counts\n";
	while(<TF>) {
	    my $v = int(  ($_ * $b / $c)   *100)/100;
	    printf OF "$v\n"; 
	}
	close(TF);
	close(OF);
	system("mv -f $tfile $counts");
    }
}

#printf STDERR Dumper \%ENV; die; 
# check for correct qsub variables needed to perform density calculations
if (!defined(%ENV)) { die "ENV variable not defined in density script submission\n" }
elsif (!defined($ENV{'force'})) { die "force rerun variable not specified by script\n"}
elsif (!defined($ENV{'genome'})) { die "genome not specific by density script script\n"}
elsif (!defined($ENV{'seqType'})) { die "sequence type not specific by density script script\n"}
elsif (!defined($ENV{'sampleName'})) {die "sample name not defined in density script\n"}
elsif (!defined($ENV{'bedmap'})) { die "bedmap file not specified by density script\n"}
elsif (!defined($ENV{'binsFile'})) { die "genomic bins file not specified by density script\n"}
elsif (!defined($ENV{'binsFileID'})) { die "genomic bins ID file not specified by density script\n"}
elsif (!defined($ENV{'tagsDir'})) { die "tags directory not defined in density script\n"}
elsif (!defined($ENV{'densityDir'})) { die "density directory not defined in density script\n"}
my $sampleFile = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tags.bed";
my $inputFile = "NA";
my $isMatched = 0;
if (defined($ENV{'inputName'}) and !bananas_agw::isNA($ENV{'inputName'})) {
    $inputFile = catfile($ENV{'tagsDir'},$ENV{'inputName'}) . "_" . $ENV{'genome'} . "_tags.bed";
    $isMatched = 1;
}

# make sure write directories exists or make them
((-d $ENV{'densityDir'}) or mkdir($ENV{'densityDir'})) or die "unable to find or create results directory: $ENV{'densityDir'}!";
my $countsDir = catfile($ENV{'densityDir'},"counts");
((-d $countsDir) or mkdir($countsDir)) or die "unable to create counts directory for density calculations\n";

# sequence-type-dependent smoothing
my $tagSmooth = 75;
if ($ENV{'seqType'} eq "rna") {
    $tagSmooth = 1;
}

# get normalized tag density counts for data with matched/unmatched background tags
my $of = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tagDensity.bed";

if ($ENV{'force'} || ! -e $of) {
  if ($isMatched) {
    my $cof1 = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tagDensity.bed.count";
    my $cof2 = catfile($ENV{'densityDir'},$ENV{'inputName'}) . "_" . $ENV{'sampleName'} . "_" . $ENV{'genome'} . "_tagDensity.bed.count";    
    system("$ENV{'bedmap'} --count --range $tagSmooth $ENV{'binsFile'} $sampleFile > $cof1");
    system("$ENV{'bedmap'} --count --range $tagSmooth $ENV{'binsFile'} $inputFile > $cof2");
    normalizeCounts($inputFile,$cof2,$sampleFile,$cof1);
    system("paste $ENV{'binsFileID'} $cof1 > $of");
    system("mv $cof1 $countsDir/");
    unlink($cof2);
  }
  else {
    my $cof1 = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tagDensity.bed.count";
    system("$ENV{'bedmap'} --count --range $tagSmooth $ENV{'binsFile'} $sampleFile > $cof1");
    normalizeCounts("NA","NA",$sampleFile,$cof1);
    system("paste $ENV{'binsFileID'} $cof1 > $of");
    system("mv $cof1 $countsDir/");
  }
}

# commented out for testing
#my $ofNuc = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_nucTagDensity.bed";
#if ($ENV{'seqType'} eq "atac") {
  #if ($ENV{'force'} || ! -e $ofNuc) {  
    #my $ofShtCounts = catfile($countsDir,$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_tags.bed.count";
    #my $ofNucCounts = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_nucTagDensity.bed.count";
    #my $ofNucTmp1 = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_nucTagDensity.bed.tmp1";
    #my $ofNucTmp2 = catfile($ENV{'densityDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_nucTagDensity.bed.tmp2";
    #my $longFile = catfile($ENV{'tagsDir'},$ENV{'sampleName'}) . "_" . $ENV{'genome'} . "_longFrags.bed";

    #system("$ENV{'bedmap'} --count --range $tagSmooth $ENV{'binsFile'} $longFile  > $ofNucCounts");
    #system("paste $ofShtCounts $ofNucCounts > $ofNucTmp1");
    #system("cat $ofNucTmp1 | awk '{x = log((\$2+1)/(\$1+1))*abs(\$2-\$1) }' > $ofNucTmp2");
    #system("paste $ENV{'binsFileID'} $ofNucTmp2 > $ofNuc");
  #}
#}
